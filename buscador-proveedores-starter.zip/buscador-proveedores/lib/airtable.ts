import Airtable from 'airtable';

const base = new Airtable({ apiKey: process.env.AIRTABLE_API_KEY })
  .base(process.env.AIRTABLE_BASE_ID!);

const TABLE = process.env.AIRTABLE_TABLE_NAME || process.env.AIRTABLE_TABLE_ID || 'Directorio de consultorios';

export type Provider = {
  id: string;
  nombre: string;
  direccion: string;
  municipio: string;
  estado: string;
  lat: number;
  lng: number;
  campañas: string[];
  tipo?: string;
  costoPublico?: number;
  costoHexalud?: number;
  telefono?: string;
  email?: string;
  especialidad?: string | string[];
};

function getField(r: any, ...names: string[]) {
  for (const n of names) {
    const v = r.get(n);
    if (v !== undefined && v !== null && v !== '') return v;
  }
  return undefined;
}

export async function listProviders({ campañas }: { campañas?: string[] } = {}): Promise<Provider[]> {
  const records = await base(TABLE).select({ maxRecords: 3000 }).all();

  const rows: Provider[] = records.map((r: any) => {
    const nombre = (getField(r,'Nombre','Nombre de proveedor','Nombre del proveedor','Nombre completo','Proveedor','Médico') as string) || '';
    const direccion = (getField(r,'Dirección de consultorio (Manual)','Dirección Completa','Direccion Completa') as string) || '';
    const municipio = (getField(r,'Ciudad o municipio','Municipio') as string) || '';
    const estado    = (getField(r,'Estado') as string) || '';
    const lat = Number(getField(r,'Lat'));
    const lng = Number(getField(r,'Lng'));
    const campañasRaw = getField(r,'Campaña Asignada','Campañas') as string | string[] | undefined;
    const campañasArr = Array.isArray(campañasRaw) ? campañasRaw : (typeof campañasRaw==='string' ? campañasRaw.split(',').map(s=>s.trim()).filter(Boolean) : []);
    const tipo = getField(r,'TipoProveedor','Tipo Proveedor') as string | undefined;
    const telefono = getField(r,'Teléfono principal ','Telefono Secundario','Teléfono','Telefono') as string | undefined;
    const email    = getField(r,'Email','Correo','Correo electrónico') as string | undefined;
    const especialidad = getField(r,'Especialidad (from Enlace con Tabla Directorio Proveedores)','Especialidad') as any;

    return { id: r.id, nombre, direccion, municipio, estado, lat, lng, campañas: campañasArr, tipo, telefono, email, especialidad };
  });

  const filtered = (campañas && campañas.length) ? rows.filter(p => p.campañas?.some(c => campañas.includes(c))) : rows;
  return filtered.filter(p => Number.isFinite(p.lat) && Number.isFinite(p.lng));
}
